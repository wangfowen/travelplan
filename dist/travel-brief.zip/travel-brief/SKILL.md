---
name: travel-brief
description: Research a travel destination and produce a single-page briefing artifact covering things to do, restaurants, neighborhoods, what to book ahead, practical basics, and country background. Use when the user names a city or country they are planning to visit, asks for trip research, a travel brief, or "what should I know about <place>".
---

# Travel Brief

Research a destination against a fixed checklist and publish the result as a single self-contained HTML artifact.

## Input

The user names a city (usually) or a country. If they name only a country, ask which city or cities before researching — most of the brief is city-scoped.

If they mention travel dates, note them; they affect reservation lead times. Do not ask for dates if not offered.

## Research procedure

Work through the sections below using web search. Search each source category separately rather than issuing one broad query — the point of this skill is consistent coverage, not speed.

### 1. Things to do

Three passes, kept as three distinct voices in the output:

- **Reddit.** Search `site:reddit.com <city> things to do`, `site:reddit.com <city> itinerary`, and the city or country subreddit directly. Weight recommendations that recur across multiple independent threads over any single enthusiastic comment. Prefer threads from the last ~2 years. Note when locals and tourists disagree — that gap is usually the interesting part.
- **Atlas Obscura.** Search `site:atlasobscura.com <city>`. Pull the genuinely odd entries, not the ones that are just the city's main museum.
- **Your own picks.** Add recommendations from your own knowledge that the above missed. Label these clearly as unsourced — they are your judgment, not a citation.

### 2. Food

- **Michelin.** Current-year starred restaurants and Bib Gourmand entries for the city. Always state the guide year — these lists change annually.
- **World's 50 Best.** Check the global list and the relevant regional list (Asia's 50 Best, Latin America's 50 Best, MENA's 50 Best, etc.), including the extended 51–100 ranking. State the year.
- **Neither list.** Add a short set of places that matter locally but hold no award — the dish the city is actually known for, and where to eat it.

### 3. Where to stay

Three to five neighborhoods. For each: one line on character, and who it suits (first visit, nightlife, quiet, families, walkability). Name the tradeoff, not just the pitch. Say plainly if an area is best avoided and why.

### 4. Book ahead

The section that has to be right, because it is time-sensitive in a way the rest is not.

Cover both:
- **Restaurants** — anything from sections above needing reservations, with how far out and through which channel (own site, Tock, Resy, phone only, hotel concierge).
- **Tours, sites, and experiences** — must-do attractions with timed entry, capacity caps, lotteries, or permit systems. These are frequently the ones that sell out furthest ahead.

Flag anything that books more than a month out. If you cannot confirm a current lead time, say so rather than estimating — a wrong number here costs the user the booking.

### 5. Practical basics

Only these three, kept short:
- Tap water potable?
- Tipping expected? If so, roughly how much and in what contexts.
- Which rideshare and taxi apps actually operate there (Uber, Bolt, Grab, Didi, local equivalents), and whether hailing or metered taxis are the norm instead.

### 6. Country background

- GDP — nominal total and per capita, with the source and year.
- Main drivers of the economy, three to four.
- History in about five beats, ending at the present. Enough to make what the user sees legible.
- Languages spoken, including how far English gets you.
- About ten travel phrases in the main language: native script, phonetic rendering, and English. Hello, please, thank you, excuse me, yes/no, do you speak English, how much is this, the bill please, where is the bathroom, cheers.

## Accuracy rules

- Anything drawn from your own knowledge rather than a search must be labeled as such.
- Award lists, GDP figures, and tipping norms all drift. Attach a year to each.
- Prefer "could not confirm" to a plausible guess, especially for lead times and tipping.

## Output

Produce **one self-contained HTML artifact**, following the structure and styling in `reference/brief-template.html`.

How you create it depends on where you are running:
- **Claude chat** — emit the artifact directly. Do not write files.
- **Claude Code** — write the HTML to a scratch file, then publish it with the Artifact tool and give the user the URL. Do not save it into the user's project.

Requirements:
- Title it `<City> — Travel Brief`.
- Include the research date near the top.
- Readable on a phone; the user will open this while traveling.
- Works in both light and dark themes.
- Book-ahead entries render as a table with a visible lead-time column.
- No external requests — inline all CSS, embed nothing remote.

After publishing, give the user a three-or-four-line summary in chat: the single highest-value thing to book immediately, and anything you could not confirm.
